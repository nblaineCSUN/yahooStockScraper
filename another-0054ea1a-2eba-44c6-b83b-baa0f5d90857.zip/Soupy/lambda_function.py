import requests
from bs4 import BeautifulSoup
import json

html_content = """
<tr class="simpTblRow Bgc($hoverBgColor):h BdB Bdbc($seperatorColor) Bdbc($tableBorderBlue):h H(32px) Bgc($lv1BgColor) ">
    <td colspan="" class="Va(m) Ta(start) Pstart(6px) Pend(10px) Miw(90px) Start(0) Pend(10px) simpTblRow:h_Bgc($hoverBgColor)  Pos(st) Bgc($lv3BgColor) Z(1)  Bgc($lv1BgColor)  Ta(start)! Fz(s)" aria-label="Symbol">
        <label data-id="portfolio-checkbox" class="Ta(c) Pos(r) Va(tb) Pend(5px) D(n)--print ">
            <input type="checkbox" class="Pos(a) Op(0) checkbox" aria-label="Select PFE">
            <svg class="Va(m)! H(16px) W(16px) checkbox:f+Stk($linkColor)! checkbox:f+Fill($linkColor)! Stk($plusGray) Fill($plusGray) Cur(p)" width="16" style="stroke-width:0;vertical-align:bottom" height="16" viewBox="0 0 24 24" data-icon="checkbox-unchecked">
                <path d="M3 3h18v18H3V3zm19-2H2c-.553 0-1 .448-1 1v20c0 .552.447 1 1 1h20c.552 0 1-.448 1-1V2c0-.552-.448-1-1-1z"></path>
            </svg>
        </label>
        <a data-test="quoteLink" href="/quote/PFE" title="Pfizer Inc." class="Fw(600) C($linkColor)">PFE</a>
        <div class="W(3px) Pos(a) Start(100%) T(0) H(100%) Bg($pfColumnFakeShadowGradient) Pe(n) Pend(5px)"></div>
    </td>
    <td colspan="" class="Va(m) Ta(start) Px(10px) Fz(s)" aria-label="Name">Pfizer Inc.</td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Fw(600) Fz(s)" aria-label="Price (Intraday)"><fin-streamer data-test="colorChange" class="" data-symbol="PFE" data-field="regularMarketPrice" data-trend="none" data-pricehint="2" value="27.72" active="">27.72</fin-streamer></td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Fw(600) Fz(s)" aria-label="Change"><fin-streamer data-test="colorChange" class="Fw(600)" data-symbol="PFE" data-field="regularMarketChange" data-trend="txt" data-pricehint="2" value="-0.220001" active=""><span class="C($negativeColor)">-0.22</span></fin-streamer></td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Fw(600) Fz(s)" aria-label="% Change"><fin-streamer data-test="colorChange" class="Fw(600)" data-symbol="PFE" data-field="regularMarketChangePercent" data-trend="txt" data-pricehint="2" value="-0.787406" active=""><span class="C($negativeColor)">-0.79%</span></fin-streamer></td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Fz(s)" aria-label="Volume"><fin-streamer data-test="colorChange" class="" data-symbol="PFE" data-field="regularMarketVolume" data-trend="none" data-pricehint="2" value="28819972" active="">28.82M</fin-streamer></td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Fz(s)" aria-label="Avg Vol (3 month)">45.166M</td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Pend(10px) W(120px) Fz(s)" aria-label="Market Cap"><fin-streamer data-test="colorChange" class="" data-symbol="PFE" data-field="marketCap" data-trend="none" data-pricehint="2" value="156965601280" active="">156.966B</fin-streamer></td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Fz(s)" aria-label="PE Ratio (TTM)">74.92</td>
    <td colspan="" class="Va(m) Ta(end) Pstart(20px) Pend(6px) Fz(s)" aria-label="52 Week Range"><canvas style="width:140px;height:23px" width="140" height="23"></canvas></td>
</tr>
"""

# Parse the HTML content
soup = BeautifulSoup(html_content, 'html.parser')

# Find all table rows with class "simpTblRow"
rows = soup.find_all('tr', class_='simpTblRow')

# Iterate through each row and extract data
for row in rows:
    symbol = row.find('a', {'data-test': 'quoteLink'}).text
    name = row.find('td', {'aria-label': 'Name'}).text
    price = row.find('td', {'aria-label': 'Price (Intraday)'}).text
    change = row.find('td', {'aria-label': 'Change'}).text
    percent_change = row.find('td', {'aria-label': '% Change'}).text
    volume = row.find('td', {'aria-label': 'Volume'}).text
    avg_volume = row.find('td', {'aria-label': 'Avg Vol (3 month)'}).text
    market_cap = row.find('td', {'aria-label': 'Market Cap'}).text
    pe_ratio = row.find('td', {'aria-label': 'PE Ratio (TTM)'}).text
    week_range = row.find('td', {'aria-label': '52 Week Range'}).text

    # Print scraped data
    print("Symbol:", symbol)
    print("Name:", name)
    print("Price:", price)
    print("Change:", change)
    print("Percent Change:", percent_change)
    print("Volume:", volume)
    print("Avg Volume:", avg_volume)
    print("Market Cap:", market_cap)
    print("PE Ratio:", pe_ratio)
    print("52 Week Range:", week_range)
    print()

  