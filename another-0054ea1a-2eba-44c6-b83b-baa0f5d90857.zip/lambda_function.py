import boto3
import requests
from bs4 import BeautifulSoup

s3 = boto3.client('s3')

def lambda_handler(event, context):
    bucket = 'activemovers'
    html_file_name = 'index.html'
    markdown_file_name = 'stock-results-1.md'

    # URL of the webpage to scrape
    url = 'https://finance.yahoo.com/most-active/'

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    # Send a GET request to the URL
    response = requests.get(url, headers=headers)

    # Check if the response was successful (200 OK)
    if response.status_code != 200:
        print(f"Failed to retrieve page, status code: {response.status_code}")
        return {
            'statusCode': 500,
            'body': f"Failed to retrieve page, status code: {response.status_code}"
        }
    
    # Parse the HTML content of the webpage
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find all table rows
    table_rows = soup.find_all('tr')

    # Initialize a list to store stock data dictionaries
    stock_data = []

    # Iterate through each table row and extract stock data
    for row in table_rows:
        # Extract symbol
        symbol_tag = row.find('span', class_='symbol yf-1fqyif7')
        symbol = symbol_tag.text.strip() if symbol_tag else 'N/A'

        # Extract name
        name_tag = row.find('div', class_='yf-362rys')
        name = name_tag.text.strip() if name_tag else 'N/A'

        # Extract price
        price_tag = row.find('fin-streamer', {'data-test': 'change'})
        price = float(price_tag['data-value']) if price_tag else 'N/A'

        # Extract change
        change_tag = row.find('fin-streamer', {'data-test': 'colorChange'})
        change = float(change_tag['data-value']) if change_tag else 'N/A'

        # Extract percent change
        percent_change_tag = row.find('fin-streamer', {'data-test': 'colorChange', 'data-field': 'regularMarketChangePercent'})
        percent_change_value = percent_change_tag['data-value'] if percent_change_tag else 'N/A'

        # Round off decimal values to two decimal places
        price = round(price, 2) if price != 'N/A' else 'N/A'
        change = round(change, 2) if change != 'N/A' else 'N/A'
        percent_change = round(float(percent_change_value), 2) if percent_change_value != 'N/A' else 'N/A'

        # Ensure only rows with data are appended
        if symbol != 'N/A' and price != 'N/A':
            stock_data.append({
                'Symbol': symbol,
                'Name': name,
                'Price': price,
                'Change': change,
                'Percentage Change': percent_change
            })

    # Generate HTML content with dynamic table rows
    html_content = generate_html_table(stock_data)

    # Generate Markdown content
    markdown_content = generate_markdown_table(stock_data)

    # Upload HTML and Markdown files to S3
    try:
        s3.put_object(Bucket=bucket, Key=html_file_name, Body=html_content.encode('utf-8'), ContentType='text/html')
        print('HTML file uploaded successfully')

        s3.put_object(Bucket=bucket, Key=markdown_file_name, Body=markdown_content.encode('utf-8'), ContentType='text/markdown')
        print('Markdown file uploaded successfully')
    except Exception as e:
        print(f'Error uploading files to S3: {e}')
        raise

    return {
        'statusCode': 200,
        'body': 'Data scraped and files uploaded to S3 successfully!'
    }

def generate_html_table(stock_data):
    html_table = "".join(
        f"<tr><td style='border: 1px solid #dddddd; text-align: left; padding: 8px;'>{stock['Symbol']}</td>"
        f"<td style='border: 1px solid #dddddd; text-align: left; padding: 8px;'>{stock['Name']}</td>"
        f"<td style='border: 1px solid #dddddd; text-align: left; padding: 8px;'>{stock['Price']}</td>"
        f"<td style='border: 1px solid #dddddd; text-align: left; padding: 8px;'>{stock['Change']}</td>"
        f"<td style='border: 1px solid #dddddd; text-align: left; padding: 8px;'>{stock['Percentage Change']}</td></tr>"
        for stock in stock_data
    )

    html_template = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Stock Data</title>
    </head>
    <body>
        <h1>Stock Data</h1>
        <table style="border-collapse: collapse; width: 100%;">
            <thead>
                <tr style="background-color: #f2f2f2;">
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Symbol</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Name</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Price</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Change</th>
                    <th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Percentage Change</th>
                </tr>
            </thead>
            <tbody>
                %dynamic_rows%
            </tbody>
        </table>
    </body>
    </html>
    """.replace("%dynamic_rows%", html_table)

    return html_template


def generate_markdown_table(stock_data):
    markdown_table = "| Symbol | Name | Price | Change | Percentage Change |\n|--------|------|-------|--------|-------------------|\n"
    markdown_table += "".join(
        f"| {stock['Symbol']} | {stock['Name']} | {stock['Price']} | {stock['Change']} | {stock['Percentage Change']} |\n"
        for stock in stock_data
    )
    return markdown_table
